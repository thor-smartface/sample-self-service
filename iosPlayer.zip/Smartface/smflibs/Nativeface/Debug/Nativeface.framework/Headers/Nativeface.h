//
//  Nativeface.h
//  Nativeface
//
//  Created by Tolga Haliloğlu on 08/03/2017.
//  Copyright © 2017 Smartface Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Nativeface.
FOUNDATION_EXPORT double NativefaceVersionNumber;

//! Project version string for Nativeface.
FOUNDATION_EXPORT const unsigned char NativefaceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Nativeface/PublicHeader.h>

#import <Nativeface/NFScriptingSupport.h>

